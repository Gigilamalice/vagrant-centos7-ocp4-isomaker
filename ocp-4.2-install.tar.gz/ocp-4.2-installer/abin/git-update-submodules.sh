#!/bin/bash
git submodule update --init --force --remote ; git add * ; 
