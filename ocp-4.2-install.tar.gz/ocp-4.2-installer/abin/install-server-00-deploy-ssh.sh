#!/bin/bash
####################################################
## 
## These tools are the property of Adlere
## usage is restricted to the final customer only.
##
## Distribution for Consulting purposes is prohibited
## without authorization.
##
## © 2018 Adlere ALL RIGHTS RESERVED
##
####################################################

export INCDIR=$(dirname "$0")
source "$INCDIR/__config__"
source "$INCDIR/__ShellLibrary__"

#####################################
# SCRIPT PART
mkdir -p "$BASEDIR/$SSHKEYDIR"
if [ ! -e $BASEDIR/$SSHKEYDIR/id_rsa ];
then
  ssh-keygen -f $BASEDIR/$SSHKEYDIR/id_rsa -t rsa -N ''
fi

#####################################
installSSHKeys
installPython
