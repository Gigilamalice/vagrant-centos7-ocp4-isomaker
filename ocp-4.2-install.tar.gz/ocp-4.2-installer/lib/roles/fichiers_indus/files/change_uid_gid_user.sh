#!/bin/bash

#-------------------------------------------------------------------------------
#@(#)
#@(#) Nom du script             : change_uid_gid_user.sh
#@(#) Description               : changement des uid et gid des comptes et groupes redhat
#@(#)                           : en fonction du fichier de parametre /admin/systeme/current/ptech/param/change_uid_gid_user.param
#-------------------------------------------------------------------------------
#@(#) Usage                     : /admin/systeme/current/ptech/bin/change_uid_gid_user.sh
#@(#) Parametres                :
#@(#) Nombres de Parametres     :
#-------------------------------------------------------------------------------
#@(#)__Ver_|_Modifie_le_|_Par________|_Objet____________________________________
#@(#)  1.0 | 30/08/17   | SHO        | Creation
#@(#)      |            |            |
#-------------------------------------------------------------------------------

#------------------------------------------------
# Debut de la valorisation des variables communes
#------------------------------------------------

if [ -f "globalsysptech.conf" ]
then
        . ./globalsysptech.conf
else
        /bin/echo "${NOM_SCRIPT}: ERREUR - Le fichier "globalsysptech.conf" n'existe pas!\n"
        exit 1
fi

#------------------------------------------------
# variables
#------------------------------------------------

if [ -z "${SCRIPT}" ]
then
        SCRIPT=$(basename $0 | cut -f 1 -d .)
fi

DATE=$(date +%Y%m%d-%OH%OM%OS)
NOM_SCRIPT_COMPLET=$0
NOM_SCRIPT="`/usr/bin/basename ${0}`"
FIC_LOG="${REP_PTECH_LOG}/${SCRIPT}_${DATE}.log"


#---------------------------------------------------------------------------
# Capture des signaux, nettoyage fichiers temporaires et arret des processes
#---------------------------------------------------------------------------

#------------------------------------------------
# Definition du PATH
#------------------------------------------------
PATH=/usr/bin:/usr/sbin:/usr/ucb:/bin:/sbin

#------------------------------------------------
# Export des variables
#------------------------------------------------
export PATH
#------------------------------------------------
# Valorisation des variables du script
#------------------------------------------------
FIC_CH_UID_GID_PARAM=/tmp/change_uid_gid_user.param
FIC_PASSWD=/etc/passwd
FIC_GROUP=/etc/group
FIC_GROUP_TMP=/tmp/fich_group_tmp.txt
FIC_USER_TMP=/tmp/fich_user_tmp.txt
FIC_DROIT_GROUP_TMP=/tmp/fichier_droit_group.txt
FIC_DROIT_UTIL_TMP=/tmp/fichier_droit_util.txt
FIC_SERV_TMP=/tmp/fichier_service.txt

# Purge fichier temporaire

if [ -f "${FIC_GROUP_TMP}" ]
 then
  rm -f "${FIC_GROUP_TMP}"
fi
if [ -f "${FIC_USER_TMP}" ]
 then
  rm -f "${FIC_USER_TMP}"
fi
if [ -f "${FIC_DROIT_GROUP_TMP}" ]
 then
  rm -f "${FIC_DROIT_GROUP_TMP}"
fi
if [ -f "${FIC_DROIT_UTIL_TMP}" ]
 then
  rm -f "${FIC_DROIT_UTIL_TMP}"
fi
if [ -f "${FIC_SERV_TMP}" ]
 then
  rm -f "${FIC_SERV_TMP}"
fi


echo -e "Creation des fichiers temporaires et arret de services"  | tee -a ${FIC_LOG}

egrep -v "^$|^#|^N" $FIC_CH_UID_GID_PARAM | while read USER_MAIF UID_MAIF GROUP_MAIF GID_MAIF SERVICE
do
 if grep -q "${USER_MAIF}" "${FIC_PASSWD}" || grep -q "${GROUP_MAIF}" "${FIC_GROUP}"
  then
	 echo -e "Fichier temporaire utilisateurs natifs" | tee -a ${FIC_LOG}
         grep "${USER_MAIF}" "${FIC_PASSWD}" >> "${FIC_USER_TMP}" 
	 cat "${FIC_USER_TMP}" | tee -a ${FIC_LOG}
         echo -e "Fichier temporaire groupes natifs" | tee -a ${FIC_LOG}
         grep "${GROUP_MAIF}" "${FIC_GROUP}" >> "${FIC_GROUP_TMP}"
	 cat "${FIC_GROUP_TMP}" | tee -a ${FIC_LOG} 
         GID_NATIF=$(cat ${FIC_GROUP_TMP} | grep ${GROUP_MAIF} | awk -F ":" '{print $3}')
         UID_NATIF=$(cat ${FIC_USER_TMP} | grep ${USER_MAIF} | awk -F ":" '{print $3}')
	 echo -e "Recherche des groupes natifs positionnes sur les fichiers et repertoires" | tee -a ${FIC_LOG}
         find / -not -path '/proc*' -not -path '/dev*' -not -path '/sys*' -gid "${GID_NATIF}" -exec ls -ld {} \; | awk '{print $4,$NF}' >> ${FIC_DROIT_GROUP_TMP}
 	 cat ${FIC_DROIT_GROUP_TMP} | tee -a ${FIC_LOG}
	 echo -e "Recherche des proprietaires positionnes sur les fichiers et repertoires" | tee -a ${FIC_LOG}
         find / -not -path '/proc*' -not -path '/dev*' -not -path '/sys*' -uid "${UID_NATIF}" -exec ls -ld {} \; | awk '{print $3,$NF}' >> ${FIC_DROIT_UTIL_TMP} 
	 cat ${FIC_DROIT_UTIL_TMP} | tee -a ${FIC_LOG}

         if [ "${SERVICE}" != "_" ]
          then
		echo -e "\n Arret des services" | tee -a ${FIC_LOG}
		service "${SERVICE}" status |  tee -a ${FIC_LOG}
		CODE_RET=$?
		if [ "${CODE_RET}" == 0 ]
		 then
                  service "${SERVICE}" stop  2>> ${FIC_LOG} 1>> ${FIC_LOG}
		  echo -e "${SERVICE}" >> "${FIC_SERV_TMP}"
		 else
		  echo -e "le service n'est pas actif" |  tee -a ${FIC_LOG}
		fi
         fi
 fi
done

echo -e "\nSuppression des utilisateurs et groupes" | tee -a ${FIC_LOG}

egrep -v "^$|^#|^N" $FIC_CH_UID_GID_PARAM | while read USER_MAIF UID_MAIF GROUP_MAIF GID_MAIF SERVICE
do
  while IFS=: read USER_NATIF PASS_NATIF UID_NATIF GID_NATIF COM_NATIF HOME_NATIF SHELL_NATIF
  do
   if [ "${USER_MAIF}" == "${USER_NATIF}" ]
    then
       echo -e "Suppression de l'utilisateur : ${USER_MAIF}" | tee -a ${FIC_LOG}
       userdel "${USER_MAIF}" 2>> ${FIC_LOG} 
   fi
  done < "${FIC_USER_TMP}"
  while IFS=: read GROUP_NATIF PASS_NATIF GID_NATIF
  do
   if [ "${GROUP_MAIF}" == "${GROUP_NATIF}" ]
    then
       echo -e "Suppression du groupe : ${GROUP_MAIF}" | tee -a ${FIC_LOG}
       groupdel "${GROUP_MAIF}" 2>> ${FIC_LOG}
   fi
  done < "${FIC_GROUP_TMP}"
done

echo -e "Recreation des groupes et positionnement des groupes sur les fichiers \n" | tee -a ${FIC_LOG}

egrep -v "^$|^#|^N" $FIC_CH_UID_GID_PARAM | while read USER_MAIF UID_MAIF GROUP_MAIF GID_MAIF SERVICE
do
  while IFS=: read GROUP_NATIF PASS_NATIF GID_NATIF
   do
        if [ "${GROUP_MAIF}" == "${GROUP_NATIF}" ]
         then
	   echo -e "Creation du group ${GID_MAIF}" | tee -a ${FIC_LOG}
           groupadd -g "${GID_MAIF}" "${GROUP_MAIF}" 2>> ${FIC_LOG} 
        fi
   done < "${FIC_GROUP_TMP}"
done

echo -e "\nOn repositionne les groupes sur les fichiers \n" | tee -a ${FIC_LOG}
while read grp file
 do
  chgrp -h $grp $file 2>> ${FIC_LOG}  
 done < "${FIC_DROIT_GROUP_TMP}"

echo -e "\nRecreation des utilisateurs et positionnement des proprietaire sur les fichiers \n" | tee -a ${FIC_LOG}

egrep -v "^$|^#|^N" $FIC_CH_UID_GID_PARAM | while read USER_MAIF UID_MAIF GROUP_MAIF GID_MAIF SERVICE
do
 while IFS=: read USER_NATIF PASS_NATIF UID_NATIF GID_NATIF COM_NATIF HOME_NATIF SHELL_NATIF
  do
    if [ "${USER_MAIF}" == "${USER_NATIF}" ]
     then
       echo -e "Creation du user : ${USER_MAIF}" | tee -a ${FIC_LOG}
       useradd -u "${UID_MAIF}" -g "${GID_MAIF}" -c "$COM_NATIF" -d "${HOME_NATIF}" -s "${SHELL_NATIF}" "${USER_MAIF}" 2>> ${FIC_LOG} 1>> ${FIC_LOG}
    fi
  done < "${FIC_USER_TMP}"
done

echo -e "\nOn repositionne les proprietaire des fichiers \n" | tee -a ${FIC_LOG}

 while read user file
  do
   chown $user $file 2>> ${FIC_LOG} 1>> ${FIC_LOG}
  done < "${FIC_DROIT_UTIL_TMP}"

echo -e "\nRedemarrage des services \n" | tee -a ${FIC_LOG}

while read SERVICE
do
  service "${SERVICE}" start 2>> ${FIC_LOG} 1>> ${FIC_LOG}
done < "${FIC_SERV_TMP}"

echo -e "\nOn supprime les fichiers temporaires \n" | tee -a ${FIC_LOG}

rm -f "${FIC_GROUP_TMP}" 
rm -f "${FIC_USER_TMP}"
rm -f "${FIC_DROIT_UTIL_TMP}"
rm -f "${FIC_DROIT_GROUP_TMP}"
rm -f "${FIC_SERV_TMP}"
