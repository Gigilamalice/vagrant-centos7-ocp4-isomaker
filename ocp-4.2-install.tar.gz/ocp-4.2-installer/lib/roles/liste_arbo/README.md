Role Name
=========

Ce role contient la liste des arbos par produit (lv, fs, repertoires, liens)
Ce role ne contient pas de tasks: il est un pre-requis des roles crea_arbo et rm_arbo


Requirements
------------

N/A

Role Variables
--------------

N/A

Dependencies
------------

- crea_arbo
- rm_arbo

Example Playbook
----------------

Dans meta/main.yml:

    dependencies: 
      - role: "liste_arbo"

License
-------

BSD

Author Information
------------------

An optional section for the role authors to include contact information, or a website (HTML is not allowed).
