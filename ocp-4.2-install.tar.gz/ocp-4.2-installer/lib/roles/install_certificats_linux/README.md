install_certificats_linux
=========

Deploie les certificats des authorités de certification

Requirements
------------

S'applique sur RHEL6 et RHEL7 uniquement (pour l'instant)

Role Variables
--------------

N/A

Dependencies
------------

N/A

Example Playbook
----------------

Including an example of how to use your role (for instance, with variables passed in as parameters) is always nice for users too:

    - hosts: servers
      roles:
         - install_certificats_linux

License
-------

N/A

Author Information
------------------

Cyril THIVET SOGETI
