Role Name
=========

Role commun de création de FS, répertoires et liens symboliques en fonction d'un produit

Requirements
------------

N/A

Role Variables
--------------

produit: "{{ nom du produit }}"

Les arborescences sont définies en fonction des produits dans le fichier defaults/main.yml du role.


Dependencies
------------

- role: liste_arbo

Example Playbook
----------------


Appel simple du role:

    - hosts: all
      become: yes
      become_user: root
      vars:
         - produit: "postinstall"
      roles:
         - crea_arbo

Appel du role dans une boucle:

    - hosts: all
      become: yes
      become_user: root
      vars:
           - produit: "addcosec"
      tasks:
           - name: Appel du role crea_arbo
             with_items: "{{ ansible_env.COS.split(',') }}"
             include_role: name=crea_arbo
             when: ansible_env.COS != ""
             loop_control:
                 loop_var: varcos


License
-------

N/A

Author Information
------------------

Cyril THIVET (sogeti)
