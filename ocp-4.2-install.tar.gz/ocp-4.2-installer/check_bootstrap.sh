openshift-install --dir=/opt/openshift.caas-sandbox wait-for bootstrap-complete  --log-level debug
